var data = {
  "type": "Feature",
  "geometry": {
    "type": "MultiPoint",
    "coordinates": [
      [
        -122.66024827,
        45.46457018
      ]
    ]
  },
  "properties": {
    "time": [
      1367898286000
    ],
    "speed": [
      0
    ],
    "altitude": [
      20
    ],
    "heading": [
      0
    ],
    "horizontal_accuracy": [
      14
    ],
    "vertical_accuracy": [
      0
    ],
    "raw": []
  },
  "bbox": [
    [
      -122.66024827,
      45.46457018
    ],
    [
      -122.66024827,
      45.46457018
    ],
    [
      -122.66024827,
      45.46457018
    ],
    [
      -122.66024827,
      45.46457018
    ]
  ]
};