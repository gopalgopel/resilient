/* global require, L */

L.TimelineVersion = '1.0.0-beta';

require('./Timeline.js');
require('./TimelineSliderControl.js');

// webpack requires
require('./leaflet.timeline.sass');
